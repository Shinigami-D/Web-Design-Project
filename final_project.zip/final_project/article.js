function validate(){
    rating=document.getElementById("rating").value;
    alert(rating)

    comments=document.getElementById("comments").value;
    alert(comments)
}